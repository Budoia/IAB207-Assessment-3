from flask import Blueprint, render_template, request, session

mainbp= Blueprint('main', __name__)

@mainbp.route('/')
def index():
    if 'email' in session:
    return render_template('langingpage.html')

@mainbp.route('/login', methods=['GET', 'POST'])
def login():
    print(request.values.get('email'))
    print(request.values.get('pwd'))
    session['email']= request.values.get('email')
    return render_template('login.html')

@mainbp.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email', None)
    return 'You have been logged out'