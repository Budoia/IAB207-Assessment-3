import flask import flask


def create_app():
    app = Flask(__name__)
    app.secret_key= 'spookysecretkey'

    from . import views
    app.register_blueprint(views.mainbp)

    from . import movies
    app.register_blueprint(movies.bp)

    return app