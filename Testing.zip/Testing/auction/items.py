from flask import Blueprint, render_template
from .models import Item, Comment


bp = Blueprint('item', __name__, url_prefix='/items') # written as "destinations" in workshop videos#

@bp.route('/<id>')
def show(id):
    item = get_item()
    return render_template('items/itemdetails.html', item=item) #show a signle movie's details


def get_item():
    i1_desc = "" #item 1 description
    image_loc = "" #item 1 image location
    item = Item () #enter list of information in the order listed under Item class in models.py
    comment = Comment() #same situation for comments
    item.set_comments(comment)
    return item