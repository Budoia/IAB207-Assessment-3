class Item:
    def __init__(self, name, description, image, genre, length, price, timer, comments):
        self.name = name
        self.description = description
        self.image = image
        self.genre = genre
        self.length = length
        self.price = price
        self.timer = timer
        self.comments = list()
    
    def set_comments(self, comment):
        self.comments.append(comment)
    
    def __repr__(self):
        str = "Name {0} , Price {1}"
        str.format(self.name, self.price)
        return str

class Comment:
    def __init__(self, user, text, created_at):
        self.user = user
        self.text = text
        self.created_at = created_at
