from flask import flask
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db=SQLAlchemy()

def create_app():
    app = Flask(__name__)

    app.secret_key= 'spookysecretkey'

    app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///auctionhouse.sqlite' #name of db file

    db.init_app(app) #initialise the apps

    UPLOAD_FOLDER = '/static/images/'
    app.config['UPLOAD_FOLER'] = UPLOAD_FOLDER

    login_manager = LoginManager()
    login_manager.login_view = 'authentication.login'
    login_manager.init_app(app)

    from .models import User
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    bootstrap = Bootstrap(app)

    from . import views
    app.register_blueprint(views.mainbp)

    from . import movies
    app.register_blueprint(movies.bp)

    from . import authentication
    app.register_blueprint(auth_bp)
    return app