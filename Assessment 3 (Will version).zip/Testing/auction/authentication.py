from flask import Blueprint, session, redirect, url_for, render_template
from .forms import LoginForm, RegisterForm
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, logout_user, login_required


auth_bp = Blueprint('authentication', __name__, url_prefix'/authentication')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    login_form = LoginForm()
    error = None

    if login_form.validate_on_submit():
        username = loginForm.username.data
        pwd = loginForm.password.data

        u = User.query.filter_by(name=username).first()
        if u is None:
            error= "Incorrect Username or Password"
        elif not check_password_hash(u.password_hash, pwd):
            error= "Incorrect Username or Password"
        #Is they sign in correctly
        if error is None:
            login_user(u)
            return redirect(url_for('templates/langingpage.html'))
        else:
            flask (error)

        return(urlfor('authentication.login'))
    
    return render_template('authentication/login.html', form = login_form)


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
     register_form = RegisterForm()

    if login_form.validate_on_submit():
        username = registerForm.username.data #Grabs information
        email = registerForm.email_id.data
        pwd = RegisterForm.password.data
        u = User.query.filter_by(name=username).first() #checks username
        if u:
            flash('This username already exists. Please try again')
        else: #if unique, is created
            pwd_hash = generate_password_hash(pwd)
            new_user = User(name=name, emailid=email, password_hash=pwd_hash)

            db.session.add(new_user)
            db.session.commit()

            return(urlfor('authentication.login'))

    return render_template('authentication/register.html', form = register_form)


@auth_bp.route('/logout', methods=['GET'])
@login_required
def logout():
    logout_user()
    return render_template('templates/langingpage.html')