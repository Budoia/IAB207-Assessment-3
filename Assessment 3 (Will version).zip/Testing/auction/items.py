from flask import Blueprint, render_template, url_for
from .models import Item, Comment
from .forms import ItemForm, CommentForm
from . import db
import os
from werkzeug.utils import secure_filename
from flask_login import login_required, current_user


bp = Blueprint('item', __name__, url_prefix='/items') # written as "destinations" in workshop videos#

@bp.route('/<id>')
def show(id):
    item = Item.query.filter_by(id=id).first()
    comment_form = CommentForm()
    return render_template('items/itemdetails.html', item=item, form=comment_form) #show a signle movie's details


@bp.route('/<id>/comment', methods=['POST'])
@login_required
def comment(id):
    comment_form = CommentForm()
    item_object = Item.query.filter_by(id=id).first()
    if comment_form.validate_on_submit():
        comment = Comment(text=form.text.data, item=item_object, user=current_user.name)

        db.session.add(comment)
        db.session.commit()
        print('The comment is valid')
    else:
        print('The comment is unvalid')
    return redirect(url_for('item.show', id=id))


def check_upload_file(form):
    fp = form.image.data
    filename = fp.filename
    BASE_PATH = os.path.dirname(__file__)

    upload_path = os.path.join(
        BASE_PATH, 'static/images', secure_filename(filename))
    
    db_upload_path = '/static/images/' + secure_filename(filename)
    fp.save(upload_path)
    return db_upload_path


@items_blueprint.route('/create', methods = ['GET', 'POST'])
@login_required
def create():
    item_form = ItemForm()
    if item_form.validate_on_submit():
        db_file_path = check_upload_file(form)

        item = Item(name=form.name.data,
                    description=form.description.data,
                    image=db_file_path,
                    price=form.price.data,
                    genre=form.genre.data,
                    length=form.length.data,
                    timer=form.timer.data)
        db.session.add(item)
        db.session.commit()
        print ('Upload was valid')
        return redirect(url_for('main.index')) #after submission, user is sent to homepage
    else:
        print('Unvalid attempt. Please try again')
    return render_template('items/itemcreation.html', form=item_form)


def get_item():
    i1_desc = "" #item 1 description
    image_loc = "" #item 1 image location
    item = Item () #enter list of information in the order listed under Item class in models.py
    comment = Comment() #same situation for comments
    item.set_comments(comment)
    return item