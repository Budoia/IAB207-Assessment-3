from flask import Blueprint, render_template, request, session
from .models import Item

mainbp= Blueprint('main', __name__)

@mainbp.route('/')
def index():
    items = Item.query.all()
    if 'email' in session:
    return render_template('langingpage.html', destinations = destinations)
    else:
        return render_template('langingpage.html', destinations = destinations)


@mainbp.route('/login', methods=['GET', 'POST'])
def login():
    print(request.values.get('email'))
    print(request.values.get('pwd'))
    return render_template('login.html')

@mainbp.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email', None)
    return 'You have been logged out'