from flask_wtf import FlaskForm
from wtforms.fields import TextAreaField, SubmitField, StringField, PasswordField, DateTimeField
from wtforms.validators import InputRequired, Length, Email, EqualTo
from flask_wtf.file import FileField, FileRequired, FileAllowed


ALLOWED_FILES = {'png', 'PNG', 'jpg', 'JPG'}



class ItemForm(FlaskForm):
  name = StringField('Title', validators=[InputRequired('Title is required')])
  description = TextAreaField('Description', validators=[InputRequired('Description  is required'), Length(min=10, max =500, message='Description must be within 10 and 500 characters long')])
  image = FileField('Item Image', validators=[InputRequired('Item image is required')])
  genre = StringField('Genre', validators=[InputRequired('Genre is required'), FileAllowed(ALLOWED_FILES, message='Image file must be PNG or JPEG')])
  Length = StringField('Length', validators=[InputRequired('Length is required'), Length(max=4, message='Length must be under 9999 pages long')])
  price = StringField('Starting Price', validators=[InputRequired('Starting price is required')])
  timer = DateTimeForm('Time the auction will end', validators=[InputRequired('Timer is required')])
  submit = SubmitField("Upload")
  
  #this should already be there in the forms.py
  
class CommentForm(FlaskForm):
  comment = TextAreaField('Comment', validators=[InputRequired("Comment is required"), Length(min=10, max=200, message="Comment must be between 10 and 200 characters long")])
  submit= SubmitField('Add your Comment')

#creates the login information
class LoginForm(FlaskForm):
    user_name=StringField("User Name", validators=[InputRequired('Enter user name')])
    password=PasswordField("Password", validators=[InputRequired('Enter user password')])
    submit = SubmitField("Login")

 # this is the registration form
class RegisterForm(FlaskForm):
    user_name=StringField("User Name", validators=[InputRequired()]s)
    email_id = StringField("Email Address", validators=[Email("Please enter a valid email")])
    
    #linking two fields - password should be equal to data entered in confirm
    password=PasswordField("Password", validators=[InputRequired(),
                  EqualTo('confirm', message="Passwords should match")])
    confirm = PasswordField("Confirm Password")
    #submit button
    submit = SubmitField("Register Account")