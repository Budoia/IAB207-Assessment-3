from . import db
from datetime import datetime
from flask_login import UserMixin



class Item(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), index=True, unique=True, nullable=False)
    description = db.Column(db.String(500), index=True, nullable=False)
    image = db.Column(db.String(50), index=True, nullable=False)
    genre = db.Column(db.String(20), index=True, nullable=False)
    length = db.Column(db.String(20), index=True, nullable=False)
    price = db.Column(db.Integer, index=True, nullable=False)
    timer = db.Column(db.DateTime, index=True, unique=True, nullable=False)

    comments = db.relationship('Comment', backref='item')

    def __repr__(self): #the string print method
        return '<Name: {}>'.format(self.name)


class Comment(db.Model):
    __tablename__ + 'comments'
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(500), index=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now(), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    item_id = db.Column(db.Integer, db.ForeignKey('items.id'))

    def __repr__(self):
        return '<Comment: {}>'.format(self.text)


class User(db.Model):
    __tablename__='users'
    id =db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), index=True, unique=True, nullable=False)
    emailid = db.Column(db.String(100), index=True, unique=True, nullable=False)
    password_hash = db.Column(db.String(50), nullable=False)
    comments = db.relationship('Comment', backref='user')